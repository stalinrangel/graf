import { Component } from '@angular/core';


@Component({
  selector: 'ngx-pages-simples',
  template: `
      <router-outlet></router-outlet>
  `,
})
export class PagesSimplesComponent {

}
