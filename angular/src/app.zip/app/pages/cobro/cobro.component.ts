import { Component } from '@angular/core';

@Component({
  selector: 'ngx-socios-elements',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class CobroComponent {
}
